package com.capgemini.FirstProject;



/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println("hello world");
       
    }
}

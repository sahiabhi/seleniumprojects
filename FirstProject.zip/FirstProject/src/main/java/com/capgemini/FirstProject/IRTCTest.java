package com.capgemini.FirstProject;

import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class IRTCTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\software\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		//loading web page few secs
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		driver.manage().window().maximize();
		
		driver.get("http://demo.guru99.com/popup.php");
		
		
		driver.findElement(By.xpath("/html/body/p")).click();
		// it will return parent window name has a string
		String parent=driver.getWindowHandle();
		
		Set<String> c=driver.getWindowHandles();
		
		//Now iterate using Iterator
		Iterator<String> lt=c.iterator();
		
		while(lt.hasNext())
		{
			String child_window1=lt.next();
			
			
			
			if(!parent.equals(child_window1))
			{
				  driver.switchTo().window(child_window1);
				  System.out.println(driver.switchTo().window(child_window1).getTitle());
				  
				  driver.findElement(By.name("emailid")).sendKeys("sahini@gmail.com");
				  driver.findElement(By.name("btnLogin")).click();
				  
				  
				  //driver.close();
			}
		}
		  // driver.switchTo().window(parent);
		
		
		

	}

}

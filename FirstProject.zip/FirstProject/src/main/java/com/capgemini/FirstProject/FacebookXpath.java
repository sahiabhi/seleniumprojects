package com.capgemini.FirstProject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class FacebookXpath {

	public static void main(String[] args) {
		
	    
System.setProperty("webdriver.chrome.driver", "C:\\software\\chromedriver.exe");
		
		WebDriver driver=new ChromeDriver();
		        driver.get("C:\\software\\table.html");


		        int rows= driver.findElements(By.xpath("html/body/table/tbody/tr")).size();
		        System.out.println(rows);



		        int columns= driver.findElements(By.xpath("html/body/table/tbody/tr/th")).size();
		        System.out.println(columns);


		        for(int i=2;i<=rows;i++)
		        {
		          for(int j=1;j<=columns;j++)
		           {
		          System.out.println(   driver.findElement(By.xpath("html/body/table/tbody/tr["+i+"]/td["+j+"]")).getText()  );
		           }

	}

	}
}

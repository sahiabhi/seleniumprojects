package com.capgemini.FirstProject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class FacebookTest {

	public static void main(String[] args) {
		
System.setProperty("webdriver.chrome.driver", "C:\\software\\chromedriver.exe");
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.facebook.com/");
		//WebElement forgotLink=driver.findElement(By.linkText("Forgotten account?"));
		WebElement search=driver.findElement(By.xpath("//input[@id=\"email\"]"));
		search.submit();
		search.clear();
				//forgotLink.click();
	}

}

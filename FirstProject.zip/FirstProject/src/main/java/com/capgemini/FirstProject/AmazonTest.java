package com.capgemini.FirstProject;

import org.openqa.selenium.By;
import org.openqa.selenium.By.ByName;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class AmazonTest {

	public static void main(String[] args) {
System.setProperty("webdriver.chrome.driver", "C:\\software\\chromedriver.exe");
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.amazon.com/");
        WebElement search=driver.findElement(By.id("twotabsearchtextbox"));
        search.sendKeys("iphone 11");
        search.submit();
      // WebElement product=driver.findElement(By.linkText("Apple iPhone 11 (64GB)- Purple"));
     //   product.submit();
    //  WebElement addtocart=driver.findElement(By.name("submit.add-to-cart"));
    //  addtocart.click();
     // WebElement proceedtobuy=driver.findElement(By.xpath("//*[@id=\"a-popover-s-safe-modal-singleton\"]/div/div[2]/div/div/iframe"));
   //  proceedtobuy.click();
        WebElement product=driver.findElement(By.linkText("preload"));
        product.click();
        WebElement proceedtobuy=driver.findElement(By.xpath("//*[@id=\"a-popover-s-safe-modal-singleton\"]/div/div[2]/div/div/iframe"));
        proceedtobuy.click();
        
        
        
	}

}

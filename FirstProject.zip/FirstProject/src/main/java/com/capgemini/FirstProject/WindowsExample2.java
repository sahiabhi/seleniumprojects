package com.capgemini.FirstProject;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.By.ByClassName;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class WindowsExample2 {

	public static void main(String[] args) {
System.setProperty("webdriver.chrome.driver", "C:\\software\\chromedriver.exe");
		
		
	    
		WebDriver driver = new ChromeDriver();
		       

               driver.get("https://accounts.lambdatest.com/register");
               WebElement search=driver.findElement(By.name("name"));
               search.sendKeys("saahi");
              // search.submit();
               WebElement search1=driver.findElement(By.name("email"));
               search1.sendKeys("sahi@gmail.com");
             //  search1.submit();
               WebElement password=driver.findElement(By.name("password"));
               password.sendKeys("sahiniadmin12");
               WebElement companyname=driver.findElement(By.name("organization_name"));
               companyname.sendKeys("capgemini");
               WebElement phone=driver.findElement(By.name("phone"));
               phone.sendKeys("9908326021");
               WebElement agree=driver.findElement(By.name("i_agree"));
               agree.isEnabled();
               WebElement sign=driver.findElement(By.className("btn btn-dark submit-btn"));
               sign.submit();
               
               
	}
	

}

package com.capgemini.AccountRepo;

import com.capgemini.beans.Account;

public interface AccountRepository {
      boolean save(Account account);
      Account searchAccount(int accountnumber);
      boolean withdrawalaAmount(int amount);
}

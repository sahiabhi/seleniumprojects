package com.capgemini.service;

import com.capgemini.AccountRepo.AccountRepository;
import com.capgemini.beans.Account;
import com.capgemini.exception.InsfficientInitialAmountException;
import com.capgemini.exception.InsufficientBalanceException;
import com.capgemini.exception.InvalidAccountNumbereException;

public class AccountServiceImp  implements AccountService{
	
	AccountRepository accountrepository;
	
	public AccountServiceImp (AccountRepository  accountrepository)
	{
		super();
		this.accountrepository=accountrepository;
	
	}

	
	public Account createAccount(int accountnumber, int amount) throws InsfficientInitialAmountException {
		// TODO Auto-generated method stub
		
		int a,b,c;
		if(amount<500) {
			throw new InsfficientInitialAmountException();
		}
		Account account=new Account();
		account.setAccountnumber(accountnumber);
		account.setAmount(amount);
		
		if(accountrepository.save(account))
		{
			return account;
		}
		return null;
	}


	@Override
	public Account serachAccount(int accountnumber)  throws InvalidAccountNumbereException{
		
		 if(accountnumber==accountnumber)
		 {
			 throw new InvalidAccountNumbereException ();
		 }
		Account account=new Account();
		account.getAccountnumber();
		if(accountrepository.searchAccount(accountnumber) != null)
		{
			return account;
		}
		
		return null;
		
	}


	@Override
	public Account withdrawlamount(int amount) throws InsufficientBalanceException {
		// TODO Auto-generated method stub
		
		int a1;
		if(amount<=amount)
		{
			throw new InsufficientBalanceException();
		}
		Account account =new Account();
		account.getAmount();
		if(accountrepository.withdrawalaAmount(amount))
		{
			return account;
		}
		return null;
	}

}

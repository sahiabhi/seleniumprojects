package com.capgemini.service;

import com.capgemini.beans.Account;
import com.capgemini.exception.InsfficientInitialAmountException;
import com.capgemini.exception.InsufficientBalanceException;
import com.capgemini.exception.InvalidAccountNumbereException;

public interface AccountService {
  Account createAccount(int accountnumber, int amount) throws InsfficientInitialAmountException;
  Account serachAccount(int accountnumber) throws InvalidAccountNumbereException;
  Account withdrawlamount(int amount) throws InsufficientBalanceException;
}

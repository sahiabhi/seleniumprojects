package com.capgemini.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.capgemini.AccountRepo.AccountRepository;
import com.capgemini.beans.Account;
import com.capgemini.exception.InsfficientInitialAmountException;
import com.capgemini.exception.InsufficientBalanceException;
import com.capgemini.exception.InvalidAccountNumbereException;
import com.capgemini.service.AccountService;
import com.capgemini.service.AccountServiceImp;

public class AccountTest {
   AccountService accountService;
   
   
   @Mock
   AccountRepository accountrepository;
   
   @Before
   public void setUp() throws Exception {
	   MockitoAnnotations.initMocks(this);
	   
	   accountService=new AccountServiceImp(accountrepository);
   }
   
   /*
    * create account
    * 1.when the amount is less than 500 then should  throw exception
    * 2.when the valid info is passed account should be created succesfully
    * 
    */
   @Test(expected=com.capgemini.exception.InsfficientInitialAmountException.class)
   public void whenTheAmountIsLessThan500SystemShouldBeCreatedSuccessfully() throws InsfficientInitialAmountException
   {
	   accountService.createAccount(101, 400);
   }
   @Test
   public void whenThenValidInfoIsPassedAccountShouldBeCreatedSuccesfully() throws InsfficientInitialAmountException
   {
	   Account account=new Account();
	   account.setAccountnumber(101);
	   account.setAmount(5000);
	  when(accountrepository.save(account)).thenReturn(true);
	   assertEquals(account, accountService.createAccount(101, 5000));
   }

    /*
     * 1.Invalid account number
     * 2.if invalid create account
     
    
   */
   @Test(expected=com.capgemini.exception.InvalidAccountNumbereException.class)
   public void whenTheAccountNumberIsFailedToLogin() throws InvalidAccountNumbereException
   {
	   accountService.serachAccount(101);
   }
   

   @Test
   public void whenTheAccountNumberIsInvalidShouldCreatedSuccessfully() throws InvalidAccountNumbereException
   {
	   Account account=new Account();
	   account.getAccountnumber();
	   when(accountrepository.searchAccount(101)).thenReturn(account);
	  // assertEquals(account,accountService.serachAccount(101));
	   
   }
   
  
   /* withdraw
    * successful
    * insufficientBalanceException
    */
   @Test(expected=com.capgemini.exception.InsufficientBalanceException.class)
   public void whenTheAmountIsLessThanGivenAmount() throws InsufficientBalanceException
   {
	   accountService.withdrawlamount(1000);
   }
   
   @Test
   public void whenTheAmountIsGreaterThanGivenAmount() throws InsufficientBalanceException
   {
	   Account account=new Account();
	   account.getAmount();
	   when(accountrepository.withdrawalaAmount(10000)).thenReturn(false);
	   //accountService.withdrawlamount(1000);
   }
   
}



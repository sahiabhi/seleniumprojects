package com.capgemini.beans;

import javax.swing.text.AttributeSet;
import javax.swing.text.html.Option;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.After;

public class ConferenceRoomBookingPageBean {

	WebDriver driver;
	
	@FindBy(how=How.ID,id="txtFirstName")
	private WebElement FirstName;
	
	@FindBy(how=How.ID,id="txtLastName")
	private WebElement LastName;
	
	@FindBy(how=How.ID,id="txtEmail")
	private WebElement Email;
	
	@FindBy(how=How.ID,id="txtPhone")
	private WebElement Contactno;
	
	@FindBy(how=How.NAME,name="size")
	private WebElement NumberOfPeopleAttending;
	
	@FindBy(how=How.ID,id="txtAddress1")
	private WebElement StreetAddressLine1;
	
	@FindBy(how=How.ID,id="txtAddress2")
	private WebElement StreetAddressLine2;
	
	@FindBy(how=How.NAME,name="city")
	private WebElement City;
	
	@FindBy(how=How.NAME,name="state")
	private WebElement State;
	
	@FindBy(how=How.XPATH,xpath="/html/body/form/table/tbody/tr[12]/td[2]/input")
	private WebElement ConferencefullAccessmember;
	
	@FindBy(how=How.XPATH,xpath="/html/body/form/table/tbody/tr[13]/td[2]/input")
	private WebElement ConferencefullAccessnonmember;
	
	
	
	public ConferenceRoomBookingPageBean(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	
	
	public  void setenterFirstName(String FirstName) {
		this.FirstName.sendKeys(FirstName);
	}
	public String getenterFirstName() {
		return FirstName.getAttribute("value");
	}
	
	public void setenterLastName(String LastName) {
		this.LastName.sendKeys(LastName);
	}
	public String getenterLastName() {
		return LastName.getAttribute("value");
	}
	
	public void  setenterEmail(String Email) {
		this.Email.sendKeys(Email);
	}
	
	public String getenterEmail() {
		return Email.getAttribute("value");
	}
	 public void setenterContactNo(String Contactno) {
		 this.Contactno.sendKeys(Contactno);
	 }
	 public String getenterContactNo() {
			return Contactno.getAttribute("value");
		}

	 public void setNumberofattendee(String noofattendee) {
		 new Select(this.NumberOfPeopleAttending).selectByValue(noofattendee);
	 }
	 
	 public String getenterNumberofattendee() {
			return NumberOfPeopleAttending.getAttribute("value");
		}
	 
	 public void setStreetAddressLine1(String Line1) {
		 this.StreetAddressLine1.sendKeys(Line1);
	 }
	 public String getStreetAddressLine1() {
			return StreetAddressLine1.getAttribute("value");
		}
	 
	 public void setStreetAddressLine2(String Line2) {
		 this.StreetAddressLine2.sendKeys(Line2);
	 }
	 
	 public String getStreetAddressLine2() {
			return StreetAddressLine2.getAttribute("value");
		}
	 
	 public void setCity(String City) {
		 new Select(this.City).selectByVisibleText(City);
	 }
	 public String getCity() {
		 return new Select(this.City).getFirstSelectedOption().getText();
	 }
	
	 public void setState(String State)
	 {
		 new Select(this.State).selectByVisibleText(State);
	 }
	 
	 public String getState() {
		 return new Select(this.State).getFirstSelectedOption().getText();
	 }
	 public void setConferencefullAccessmember(String accessmem) {
		 new Option((AttributeSet) this.ConferencefullAccessmember).isSelected();
	 }
	 
	 public AttributeSet getConferencefullAccessmember() {
		 return new Option((AttributeSet) this.ConferencefullAccessmember).getAttributes();
	 }
	 
	public void setConferencefullAccessnonmember(String nonmem) {
		 new Option((AttributeSet) this.ConferencefullAccessnonmember).isSelected();
	}
	
	 public AttributeSet getConferencefullAccessnonmember() {
		 return new Option((AttributeSet) this.ConferencefullAccessnonmember).getAttributes();
	 }



	public boolean isInitialized() {
		return FirstName.isDisplayed();
	}
	 
	
	
	
}

package com.capgemini.test;

import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PaymentDeatilsStepDef {
	@Given("^The  user need to fill the form PaymentDeatils$")
    public void the_user_need_to_fill_the_form_paymentdeatils() throws Throwable {
        throw new PendingException();
    }

    @When("^The user enter the Firstname $")
    public void the_user_enter_the_firstname() throws Throwable {
        throw new PendingException();
    }

    @Then("^The user clicks at Register button$")
    public void the_user_clicks_at_register_button() throws Throwable {
        throw new PendingException();
    }

    @And("^The user enter the Lastname $")
    public void the_user_enter_the_lastname() throws Throwable {
        throw new PendingException();
    }

    @And("^The user enter Debit Card Number$")
    public void the_user_enter_debit_card_number() throws Throwable {
        throw new PendingException();
    }

    @And("^The user enter CVV$")
    public void the_user_enter_cvv() throws Throwable {
        throw new PendingException();
    }

    @And("^The user enter Expiration month$")
    public void the_user_enter_expiration_month() throws Throwable {
        throw new PendingException();
    }

    @And("^Th user enter Expiration Year$")
    public void th_user_enter_expiration_year() throws Throwable {
        throw new PendingException();
    }

}

package com.capgemini.stepdef;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.capgemini.beans.ConferenceRoomBookingPageBean;
import com.capgemini.urls.Urls;


import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ConferenceBookingsStepDef {
	
	   private  WebDriver driver;
	   private ConferenceRoomBookingPageBean PageBean;
	   
	   @Before
	   public void setUpSetEnv() {
		   driver=Urls.getWebDriver();
	   }
	
	 @Given("^The user need to fill the form personal deatils$")
	    public void the_user_need_to_fill_the_form_personal_deatils() throws Throwable {
		 driver.get("file:///C:/Users/ksahini/eclipse-workspace/ConferenceBookings/html/ConferenceRegistartion.html");
			PageBean = PageFactory.initElements(driver, ConferenceRoomBookingPageBean.class);
	    }

	    @When("^The user enter the Firstname $")
	    public void the_user_enter_the_firstname() throws Throwable {
	        driver.findElement(By.id("txtFirstName")).sendKeys("sai");
	    }

	    @Then("^The user clicks to Next link\\.$")
	    public void the_user_clicks_to_next_link() throws Throwable {
	    	System.out.println("The user is successfully logged into the Personal Deatils");
	    	Thread.sleep(3000);
	    }

	    @And("^The user enter the Lastname$")
	    public void the_user_enter_the_lastname() throws Throwable {
	    	 driver.findElement(By.id("txtLastName")).sendKeys("Abhi");
	    }

	    @And("^The user enter the Email$")
	    public void the_user_enter_the_email() throws Throwable {
	    	 driver.findElement(By.id("txtEmail")).sendKeys("saiabhi@gmail.com");
	    }

	    @And("^ The user enter the Contact no$")
	    public void the_user_enter_the_contact_no() throws Throwable {
	        driver.findElement(By.id("txtPhone")).sendKeys("1234567891");
	    }

	    @And("^The user enter the Number of people attending$")
	    public void the_user_enter_the_number_of_people_attending() throws Throwable {
	        driver.findElement(By.name("size")).sendKeys("1");
	    }

	    @And("^The user enter the Street Address Line1 $")
	    public void the_user_enter_the_street_address_line1() throws Throwable {
	       driver.findElement(By.id("txtAddress1")).sendKeys("1-1-102");
	    }

	    @And("^The user enter the Street Address Line2$")
	    public void the_user_enter_the_street_address_line2() throws Throwable {
	    	  driver.findElement(By.id("txtAddress2")).sendKeys("main road");
	    }

	    @And("^The user select the City$")
	    public void the_user_select_the_city() throws Throwable {
	        driver.findElement(By.name("city")).isSelected();
	    }

	    @And("^ The user select the State$")
	    public void the_user_select_the_state() throws Throwable {
	        driver.findElement(By.name("state")).isSelected();
	    }

	    @And("^The user select the Conference full\\-Access\\(member\\)\\(1000 Rs\\.\\)$")
	    public void the_user_select_the_conference_fullaccessmember1000_rs() throws Throwable {
	        driver.findElement(By.xpath("/html/body/form/table/tbody/tr[12]/td[2]/input")).isSelected();
	    }

	    @And("^The user select the Conference full\\-Access\\(non\\-member\\)\\(1500 Rs\\.\\)$")
	    public void the_user_select_the_conference_fullaccessnonmember1500_rs() throws Throwable {
	      driver.findElement(By.xpath("/html/body/form/table/tbody/tr[13]/td[2]/input")).isSelected();
	    }
	 //   @After
	//	public void tearDownScenarioEnv() {
			//	driver.close();
				//driver=null;
		//}

}

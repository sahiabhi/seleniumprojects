package com.capgemini.urls;

import static org.junit.Assert.assertTrue;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.capgemini.beans.ConferenceRoomBookingPageBean;
import com.capgemini.test.TestRunner;

public class Urls {

	public static WebDriver getWebDriver() {
		
		
		//registering driver
		System.setProperty("webdriver.chrome.driver", "C:\\software\\chromedriver.exe");
      // web driver instance
		WebDriver driver = new ChromeDriver();
		
	//	 driver.get("file:///C:/Users/ksahini/eclipse-workspace/ConferenceBookings/html/ConferenceRegistartion.html");
		
		 
		/* ConferenceRoomBookingPageBean bean=new ConferenceRoomBookingPageBean(driver);
		 assertTrue(bean.isInitialized());
		 bean.setenterFirstName("sai");
		 bean.setenterLastName("abhi");
		 bean.setenterEmail("Saiabhi@gamil.com");
		 bean.setenterContactNo("1234567898");
		 bean.setNumberofattendee("2");
		 bean.setStreetAddressLine1("11-1-129");
         bean.setStreetAddressLine2("mainroad");
         bean.setCity("pune");
         bean.setState("maharatha");
         bean.setConferencefullAccessmember("null");
         bean.setConferencefullAccessnonmember("null"); */
		 
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		
		driver.manage().timeouts().implicitlyWait(30l, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(30l, TimeUnit.SECONDS);
		return driver;
	}

	
  
}

package com.capgemini.SeleniumPOM;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;


public class SignUpEmailTest extends FunctionalTest {
	

@Test
public void signUpEmail(){
		
		driver.get("http://demo.guru99.com/popup.php");
		
		SignUpEmail signUpemail = new SignUpEmail(driver);
		assertTrue(signUpemail.isInitialized());


       signUpemail.enterEmailid("sahi@gmail.com");
       
       
       
       AccessPage accesspage=signUpemail.submit();
       assertTrue(accesspage.isInitialized());
       
       assertEquals("welcome!", accesspage.confirmationHeader());
}
}

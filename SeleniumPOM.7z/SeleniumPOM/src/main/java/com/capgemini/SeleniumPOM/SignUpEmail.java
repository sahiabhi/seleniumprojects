package com.capgemini.SeleniumPOM;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;


public class SignUpEmail extends PageObject{
	
	
	@FindBy(name="emailid")
	private WebElement EmailID;
	
	@FindBy(name="btnLogin")
	private WebElement submitbutton;

	public SignUpEmail(WebDriver driver) {
		super(driver);
	
	}
	public boolean isInitialized() {
		return EmailID.isDisplayed();
	}
	public void enterEmailid(String EmailID){
		this.EmailID.clear();
		this.EmailID.sendKeys(EmailID);
	}
	
	public AccessPage submit() {
		submitbutton.submit();
		return new AccessPage(driver);
	}
}

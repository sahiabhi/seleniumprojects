package com.capgemini.SeleniumPOM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ClickHerePage extends PageObject{
	
	public void clickhere() {
		driver.findElement(By.xpath("/html/body/p")).click();
	}
	
	
	public ClickHerePage(WebDriver driver) {
		super(driver);
		
	}

}

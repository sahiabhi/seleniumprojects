package com.capgemini.SeleniumPOM;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AccessPage extends PageObject {
	
	
	@FindBy(tagName = "h2")
	private WebElement header;
	
		
 
	public AccessPage(WebDriver driver) {
		super(driver);
		
	}
	public boolean isInitialized() {
		return header.isDisplayed();
	}

	public String confirmationHeader(){
		return header.getText();
	}
	
	
}
